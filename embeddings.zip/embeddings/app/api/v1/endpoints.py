"""API v1 endpoints - separated from main.py for clarity"""

from fastapi import APIRouter, HTTPException, Depends, status
import logging

from app.api.v1.schemas import (
    EmbedRequest,
    EmbedResponse,
    ModelsResponse,
    ModelInfo,
    CacheStatsResponse,
)
from app.config import settings
from app.dependencies import verify_api_key
from app.core.errors import ModelNotFoundError

logger = logging.getLogger(__name__)

router = APIRouter()


def get_services():
    """Get service instances from app state"""
    from app.main import model_manager, cache_service, embedding_service
    return model_manager, cache_service, embedding_service


@router.post("/embed", response_model=EmbedResponse, dependencies=[Depends(verify_api_key)])
async def embed_texts(request: EmbedRequest):
    """
    Generate embeddings for texts

    - Supports batch processing
    - Automatic caching
    - Multiple model support
    """
    model_manager, cache_service, embedding_service = get_services()

    try:
        # Validate request
        if len(request.texts) > settings.MAX_TEXTS_PER_REQUEST:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Too many texts. Maximum: {settings.MAX_TEXTS_PER_REQUEST}",
            )

        # Check text lengths
        for text in request.texts:
            if len(text) > settings.MAX_TEXT_LENGTH:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Text exceeds maximum length of {settings.MAX_TEXT_LENGTH}",
                )

        # Get model name
        model_name = request.model or settings.DEFAULT_MODEL

        # Generate embeddings
        result = await embedding_service.embed_texts(
            texts=request.texts,
            model_name=model_name,
            normalize=request.normalize,
            use_cache=request.use_cache and settings.ENABLE_CACHE,
        )

        # Get model info
        model = model_manager.get_model(model_name)

        return EmbedResponse(
            embeddings=result["embeddings"],
            model=model_name,
            dimension=model.get_dimension(),
            cached=result.get("cached"),
            usage={
                "total_texts": len(request.texts),
                "cache_hits": sum(result.get("cached", [])),
                "cache_misses": len(request.texts) - sum(result.get("cached", [])),
            },
        )

    except ModelNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except Exception as e:
        logger.error(f"Error generating embeddings: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate embeddings",
        )


@router.get("/models", response_model=ModelsResponse)
async def list_models():
    """List all available models"""
    model_manager, _, _ = get_services()
    models_info = []

    for model_name in model_manager.list_models():
        try:
            model = model_manager.get_model(model_name)
            metadata = model.get_metadata()

            models_info.append(
                ModelInfo(
                    name=metadata.name,
                    dimension=metadata.dimension,
                    max_seq_length=metadata.max_seq_length,
                    device=metadata.device,
                    memory_mb=metadata.memory_usage_mb,
                    is_default=(model_name == settings.DEFAULT_MODEL),
                )
            )
        except Exception as e:
            logger.warning(f"Could not get info for model {model_name}: {e}")

    return ModelsResponse(
        models=models_info,
        default_model=settings.DEFAULT_MODEL,
    )


@router.get("/cache/stats", response_model=CacheStatsResponse)
async def cache_stats():
    """Get cache statistics"""
    _, cache_service, _ = get_services()

    if not cache_service:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cache is not enabled",
        )

    stats = cache_service.get_stats()
    return CacheStatsResponse(**stats)


@router.post("/cache/clear")
async def clear_cache():
    """Clear the cache (admin operation)"""
    _, cache_service, _ = get_services()

    if not cache_service:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cache is not enabled",
        )

    success = await cache_service.clear()

    if success:
        return {"status": "success", "message": "Cache cleared"}
    else:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to clear cache",
        )