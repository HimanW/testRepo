from typing import List, Optional, Literal
from pydantic import BaseModel, Field, validator
from enum import Enum


class PoolingStrategy(str, Enum):
    """Available pooling strategies"""
    MEAN = "mean"
    CLS = "cls"
    MAX = "max"
    MEAN_SQRT = "mean_sqrt"


class EmbedRequest(BaseModel):
    """Request schema for embedding generation"""

    texts: List[str] = Field(
        ...,
        description="List of texts to embed",
        min_items=1,
        max_items=100,
        example=["Hello world", "This is a test"]
    )

    model: Optional[str] = Field(
        None,
        description="Model to use (defaults to service default)",
        example="BAAI/bge-base-en-v1.5"
    )

    normalize: bool = Field(
        True,
        description="Normalize embeddings to unit length"
    )

    pooling: Optional[PoolingStrategy] = Field(
        None,
        description="Pooling strategy (defaults to model default)"
    )

    truncate: bool = Field(
        True,
        description="Truncate texts that exceed max length"
    )

    use_cache: bool = Field(
        True,
        description="Use caching if available"
    )

    @validator("texts")
    def validate_texts(cls, v):
        """Validate texts are not empty"""
        if not v:
            raise ValueError("texts list cannot be empty")

        for i, text in enumerate(v):
            if not isinstance(text, str):
                raise ValueError(f"Text at index {i} must be a string")
            if not text.strip():
                raise ValueError(f"Text at index {i} cannot be empty or whitespace")

        return v

    class Config:
        schema_extra = {
            "example": {
                "texts": [
                    "The quick brown fox jumps over the lazy dog",
                    "Machine learning is a subset of artificial intelligence"
                ],
                "model": "BAAI/bge-base-en-v1.5",
                "normalize": True,
                "truncate": True,
                "use_cache": True
            }
        }


class EmbedResponse(BaseModel):
    """Response schema for embedding generation"""

    embeddings: List[List[float]] = Field(
        ...,
        description="Generated embeddings"
    )

    model: str = Field(
        ...,
        description="Model used for generation"
    )

    dimension: int = Field(
        ...,
        description="Embedding dimension"
    )

    cached: Optional[List[bool]] = Field(
        None,
        description="Indicates which embeddings were retrieved from cache"
    )

    usage: Optional[dict] = Field(
        None,
        description="Usage statistics"
    )

    class Config:
        schema_extra = {
            "example": {
                "embeddings": [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]],
                "model": "BAAI/bge-base-en-v1.5",
                "dimension": 768,
                "cached": [False, True],
                "usage": {
                    "total_texts": 2,
                    "cache_hits": 1,
                    "cache_misses": 1
                }
            }
        }


class ModelInfo(BaseModel):
    """Information about an available model"""

    name: str = Field(..., description="Model identifier")
    dimension: int = Field(..., description="Embedding dimension")
    max_seq_length: int = Field(..., description="Maximum sequence length")
    device: str = Field(..., description="Device model is loaded on")
    memory_mb: float = Field(..., description="Estimated memory usage in MB")
    is_default: bool = Field(..., description="Whether this is the default model")


class ModelsResponse(BaseModel):
    """Response schema for available models"""

    models: List[ModelInfo] = Field(
        ...,
        description="List of available models"
    )

    default_model: str = Field(
        ...,
        description="Default model identifier"
    )


class HealthResponse(BaseModel):
    """Health check response"""

    status: Literal["healthy", "degraded", "unhealthy"] = Field(
        ...,
        description="Service health status"
    )

    service: str = Field(
        ...,
        description="Service name"
    )

    version: str = Field(
        ...,
        description="Service version"
    )

    checks: dict = Field(
        ...,
        description="Individual component health checks"
    )


class ErrorResponse(BaseModel):
    """Error response schema"""

    error: str = Field(
        ...,
        description="Error type"
    )

    message: str = Field(
        ...,
        description="Error message"
    )

    detail: Optional[dict] = Field(
        None,
        description="Additional error details"
    )

    request_id: Optional[str] = Field(
        None,
        description="Request correlation ID"
    )


class CacheStatsResponse(BaseModel):
    """Cache statistics response"""

    hits: int = Field(..., description="Number of cache hits")
    misses: int = Field(..., description="Number of cache misses")
    errors: int = Field(..., description="Number of cache errors")
    sets: int = Field(..., description="Number of cache sets")
    hit_rate_percent: float = Field(..., description="Cache hit rate percentage")
    total_requests: int = Field(..., description="Total cache requests")
    connected: bool = Field(..., description="Whether cache is connected")
    enabled: bool = Field(..., description="Whether cache is enabled")