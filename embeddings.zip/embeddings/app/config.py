from typing import Optional, List, Union
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator
import os


class Settings(BaseSettings):
    """Enterprise-grade configuration management with Pydantic V2 validation"""

    # Service Configuration
    SERVICE_NAME: str = "embedding-service"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False

    # API Configuration
    API_V1_PREFIX: str = "/v1"
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 1

    # Model Configuration
    DEFAULT_MODEL: str = "BAAI/bge-base-en-v1.5"

    # IMPORTANT: We type this as Union[List[str], str] initially to allow Pydantic to read the raw string
    # The validator will then convert it to a List[str]
    AVAILABLE_MODELS: Union[List[str], str] = [
        "BAAI/bge-base-en-v1.5",
        "sentence-transformers/all-MiniLM-L6-v2",
        "intfloat/e5-base-v2"
    ]
    MODEL_CACHE_DIR: str = "./model_cache"

    # Device Configuration
    DEVICE: Optional[str] = "cuda"
    USE_FP16: bool = True
    MAX_BATCH_SIZE: int = 32

    # Cache Configuration
    ENABLE_CACHE: bool = True
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: Optional[str] = None
    REDIS_SSL: bool = False
    CACHE_TTL: int = 3600
    CACHE_MAX_SIZE: int = 10000

    # Request Configuration
    MAX_TEXT_LENGTH: int = 8192
    MAX_TEXTS_PER_REQUEST: int = 100
    REQUEST_TIMEOUT: int = 30

    # Batch Processing
    BATCH_TIMEOUT_MS: int = 50
    MIN_BATCH_SIZE: int = 1
    ENABLE_DYNAMIC_BATCHING: bool = True

    # Security
    ENABLE_AUTH: bool = False
    # Same fix for API_KEYS
    API_KEYS: Union[List[str], str] = []
    ENABLE_RATE_LIMIT: bool = True
    RATE_LIMIT_PER_MINUTE: int = 1000

    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    ENABLE_REQUEST_LOGGING: bool = True

    # Monitoring
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090

    # Performance
    ENABLE_ONNX: bool = False
    NUM_THREADS: Optional[int] = 4
    WARMUP_REQUESTS: int = 10

    # Health Checks
    HEALTH_CHECK_INTERVAL: int = 30

    # Pydantic V2 Configuration
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )

    @field_validator("AVAILABLE_MODELS", mode="before")
    @classmethod
    def parse_models(cls, v):
        # If it's already a list, return it
        if isinstance(v, list):
            return v
        # If it's a string, clean and split it
        if isinstance(v, str):
            v = v.replace("[", "").replace("]", "").replace('"', "").replace("'", "")
            return [m.strip() for m in v.split(",") if m.strip()]
        return v

    @field_validator("API_KEYS", mode="before")
    @classmethod
    def parse_api_keys(cls, v):
        if isinstance(v, list):
            return v
        if isinstance(v, str):
            return [k.strip() for k in v.split(",") if k.strip()]
        return []

    @field_validator("LOG_LEVEL")
    @classmethod
    def validate_log_level(cls, v):
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            return "INFO"
        return v.upper()

    def get_redis_url(self) -> str:
        """Construct Redis connection URL dynamically if REDIS_URL isn't set directly"""
        if self.REDIS_URL and "localhost" not in self.REDIS_URL:
            return self.REDIS_URL
        protocol = "rediss" if self.REDIS_SSL else "redis"
        auth = f":{self.REDIS_PASSWORD}@" if self.REDIS_PASSWORD else ""
        return f"{protocol}://{auth}{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"


# Global settings instance
settings = Settings()