"""Core functionality for the embedding service"""

from app.core.errors import (
    EmbeddingServiceError,
    ModelNotFoundError,
    ValidationError,
    CacheError,
)
from app.core.logging import setup_logging

__all__ = [
    "EmbeddingServiceError",
    "ModelNotFoundError",
    "ValidationError",
    "CacheError",
    "setup_logging",
]