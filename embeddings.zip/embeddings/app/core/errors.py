"""Custom exceptions for the embedding service"""

from fastapi import status


class EmbeddingServiceError(Exception):
    """Base exception for embedding service errors"""

    def __init__(self, message: str, status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class ModelNotFoundError(EmbeddingServiceError):
    """Raised when a requested model is not available"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_404_NOT_FOUND)


class ModelLoadError(EmbeddingServiceError):
    """Raised when a model fails to load"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ValidationError(EmbeddingServiceError):
    """Raised when input validation fails"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_400_BAD_REQUEST)


class CacheError(EmbeddingServiceError):
    """Raised when cache operations fail"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BatchSizeExceededError(EmbeddingServiceError):
    """Raised when batch size exceeds limits"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_400_BAD_REQUEST)


class TextTooLongError(EmbeddingServiceError):
    """Raised when input text exceeds maximum length"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_400_BAD_REQUEST)


class RateLimitExceededError(EmbeddingServiceError):
    """Raised when rate limit is exceeded"""

    def __init__(self, message: str):
        super().__init__(message, status_code=status.HTTP_429_TOO_MANY_REQUESTS)