"""Prometheus metrics for monitoring"""

from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi import Response
import time

# Request metrics
request_count = Counter(
    'embedding_requests_total',
    'Total number of embedding requests',
    ['method', 'endpoint', 'status']
)

request_duration = Histogram(
    'embedding_request_duration_seconds',
    'Request duration in seconds',
    ['method', 'endpoint']
)

# Model metrics
model_inference_duration = Histogram(
    'embedding_model_inference_duration_seconds',
    'Model inference duration in seconds',
    ['model_name']
)

# Cache metrics
cache_hits = Counter(
    'embedding_cache_hits_total',
    'Total number of cache hits',
    ['model_name']
)

cache_misses = Counter(
    'embedding_cache_misses_total',
    'Total number of cache misses',
    ['model_name']
)

# System metrics
active_requests = Gauge(
    'embedding_active_requests',
    'Number of active requests'
)

loaded_models = Gauge(
    'embedding_loaded_models',
    'Number of loaded models'
)


class MetricsMiddleware:
    """Middleware to track request metrics"""

    def __init__(self):
        self.active = 0

    async def __call__(self, request, call_next):
        # Increment active requests
        self.active += 1
        active_requests.set(self.active)

        # Track request
        method = request.method
        path = request.url.path

        start_time = time.time()

        try:
            response = await call_next(request)
            status_code = response.status_code

            # Record metrics
            request_count.labels(
                method=method,
                endpoint=path,
                status=status_code
            ).inc()

            duration = time.time() - start_time
            request_duration.labels(
                method=method,
                endpoint=path
            ).observe(duration)

            return response

        finally:
            # Decrement active requests
            self.active -= 1
            active_requests.set(self.active)


async def metrics_endpoint():
    """Endpoint to expose Prometheus metrics"""
    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )