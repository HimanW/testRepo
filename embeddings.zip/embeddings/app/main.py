import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
import time
import uuid
from typing import Optional

from app.config import settings
from app.core.logging import setup_logging
from app.core.errors import EmbeddingServiceError
from app.core.metrics import MetricsMiddleware, metrics_endpoint
from app.models.model_manager import ModelManager
from app.services.cache_service import CacheService
from app.services.embedding_service import EmbeddingService
from app.api.v1.schemas import HealthResponse, ErrorResponse
from app.api.v1 import endpoints

# Setup logging
setup_logging(settings.LOG_LEVEL, settings.LOG_FORMAT)
logger = logging.getLogger(__name__)

# Global service instances
model_manager: Optional[ModelManager] = None
cache_service: Optional[CacheService] = None
embedding_service: Optional[EmbeddingService] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global model_manager, cache_service, embedding_service

    logger.info(f"Starting {settings.SERVICE_NAME} v{settings.VERSION}")
    logger.info(f"Environment: {settings.ENVIRONMENT}")

    # Initialize model manager
    logger.info("Initializing model manager...")
    model_manager = ModelManager(
        default_model=settings.DEFAULT_MODEL,
        available_models=settings.AVAILABLE_MODELS,
        device=settings.DEVICE,
        use_fp16=settings.USE_FP16,
        cache_dir=settings.MODEL_CACHE_DIR,
    )

    # Load default model
    try:
        model_manager.load_model(settings.DEFAULT_MODEL)
        logger.info(f"Loaded default model: {settings.DEFAULT_MODEL}")
    except Exception as e:
        logger.error(f"Failed to load default model: {e}")
        raise

    # Warmup model
    if settings.WARMUP_REQUESTS > 0:
        default_model = model_manager.get_model(settings.DEFAULT_MODEL)
        default_model.warmup(settings.WARMUP_REQUESTS)

    # Initialize cache service
    if settings.ENABLE_CACHE:
        logger.info("Initializing cache service...")
        cache_service = CacheService(
            redis_url=settings.get_redis_url(),
            ttl=settings.CACHE_TTL,
            max_size=settings.CACHE_MAX_SIZE,
            enabled=settings.ENABLE_CACHE,
        )
        await cache_service.connect()

    # Initialize embedding service
    embedding_service = EmbeddingService(
        model_manager=model_manager,
        cache_service=cache_service,
        max_batch_size=settings.MAX_BATCH_SIZE,
    )

    logger.info("Service startup complete")

    yield

    # Cleanup
    logger.info("Shutting down service...")

    if cache_service:
        await cache_service.disconnect()

    logger.info("Service shutdown complete")


# Create FastAPI app
app = FastAPI(
    title=settings.SERVICE_NAME,
    description="Enterprise-grade embedding service with caching, batching, and multi-model support",
    version=settings.VERSION,
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add metrics middleware
if settings.ENABLE_METRICS:
    app.middleware("http")(MetricsMiddleware())


# Request ID middleware
@app.middleware("http")
async def add_request_id(request: Request, call_next):
    """Add request ID to all requests"""
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    request.state.request_id = request_id

    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time

    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time"] = str(process_time)

    if settings.ENABLE_REQUEST_LOGGING:
        logger.info(
            f"Request completed",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "process_time": process_time,
            }
        )

    return response


# Exception handlers
@app.exception_handler(EmbeddingServiceError)
async def embedding_error_handler(request: Request, exc: EmbeddingServiceError):
    """Handle custom embedding service errors"""
    return JSONResponse(
        status_code=exc.status_code,
        content=ErrorResponse(
            error=exc.__class__.__name__,
            message=str(exc),
            request_id=getattr(request.state, "request_id", None),
        ).dict(),
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle unexpected errors"""
    logger.error(f"Unexpected error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(
            error="InternalServerError",
            message="An unexpected error occurred",
            request_id=getattr(request.state, "request_id", None),
        ).dict(),
    )


# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """Root endpoint"""
    return {
        "service": settings.SERVICE_NAME,
        "version": settings.VERSION,
        "status": "running",
    }


# Health endpoints
@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """Comprehensive health check"""
    checks = {}

    # Check model manager
    checks["models"] = model_manager is not None

    # Check cache
    if cache_service:
        checks["cache"] = await cache_service.health_check()
    else:
        checks["cache"] = True  # No cache is fine

    # Determine overall status
    all_healthy = all(checks.values())
    status_value = "healthy" if all_healthy else "unhealthy"

    return HealthResponse(
        status=status_value,
        service=settings.SERVICE_NAME,
        version=settings.VERSION,
        checks=checks,
    )


@app.get("/ready", tags=["Health"])
async def readiness_check():
    """Readiness probe for orchestrators"""
    if model_manager is None:
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={"status": "not ready"},
        )
    return {"status": "ready"}


# Metrics endpoint
if settings.ENABLE_METRICS:
    app.get("/metrics", tags=["Monitoring"])(metrics_endpoint)

# Include API v1 routes
app.include_router(
    endpoints.router,
    prefix=settings.API_V1_PREFIX,
    tags=["Embeddings v1"]
)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        workers=settings.WORKERS,
        log_level=settings.LOG_LEVEL.lower(),
        reload=settings.DEBUG,
    )