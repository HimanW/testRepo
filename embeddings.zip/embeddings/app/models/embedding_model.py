from typing import List, Optional, Union, Literal
import torch
import numpy as np
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModel
import logging
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class PoolingStrategy(str, Enum):
    """Pooling strategies for generating embeddings"""
    MEAN = "mean"
    CLS = "cls"
    MAX = "max"
    MEAN_SQRT = "mean_sqrt"  # Mean pooling with sqrt of seq length


@dataclass
class ModelMetadata:
    """Metadata about the embedding model"""
    name: str
    dimension: int
    max_seq_length: int
    pooling_strategy: PoolingStrategy
    normalization: bool
    device: str
    memory_usage_mb: float


class EmbeddingModel:
    """
    Enterprise-grade embedding model wrapper with advanced features:
    - Multiple pooling strategies
    - Batch processing with memory management
    - FP16 support for faster inference
    - Attention mask handling
    - Proper text truncation
    """

    def __init__(
            self,
            model_name: str,
            device: Optional[str] = None,
            use_fp16: bool = False,
            cache_dir: Optional[str] = None,
            max_seq_length: Optional[int] = None,
    ):
        """
        Initialize the embedding model

        Args:
            model_name: HuggingFace model identifier
            device: Device to load model on ('cuda', 'cpu', or None for auto)
            use_fp16: Use half precision for faster inference (requires GPU)
            cache_dir: Directory to cache downloaded models
            max_seq_length: Maximum sequence length (None = use model default)
        """
        self.model_name = model_name

        # Device selection
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        self.use_fp16 = use_fp16 and self.device == "cuda"

        logger.info(
            f"Loading model '{model_name}' on device '{self.device}' "
            f"(FP16: {self.use_fp16})"
        )

        try:
            # Load model using sentence-transformers for simplicity
            self.model = SentenceTransformer(
                model_name,
                device=self.device,
                cache_folder=cache_dir
            )

            # Convert to FP16 if requested
            if self.use_fp16:
                self.model = self.model.half()

            # Set to evaluation mode
            self.model.eval()

            # Get model configuration
            self.dimension = self.model.get_sentence_embedding_dimension()
            self.max_seq_length = (
                    max_seq_length or self.model.max_seq_length
            )

            # Cache metadata
            self._metadata = self._compute_metadata()

            logger.info(
                f"Model loaded successfully: {self.dimension}D embeddings, "
                f"max_seq_length={self.max_seq_length}"
            )

        except Exception as e:
            logger.error(f"Failed to load model '{model_name}': {e}")
            raise

    def _compute_metadata(self) -> ModelMetadata:
        """Compute model metadata"""
        # Estimate memory usage
        param_count = sum(p.numel() for p in self.model.parameters())
        bytes_per_param = 2 if self.use_fp16 else 4
        memory_mb = (param_count * bytes_per_param) / (1024 * 1024)

        return ModelMetadata(
            name=self.model_name,
            dimension=self.dimension,
            max_seq_length=self.max_seq_length,
            pooling_strategy=PoolingStrategy.MEAN,  # Default for sentence-transformers
            normalization=True,
            device=self.device,
            memory_usage_mb=memory_mb
        )

    @torch.no_grad()
    def encode(
            self,
            texts: Union[str, List[str]],
            batch_size: int = 32,
            normalize: bool = True,
            show_progress: bool = False,
            convert_to_numpy: bool = True,
            pooling: Optional[PoolingStrategy] = None,
    ) -> Union[np.ndarray, torch.Tensor]:
        """
        Encode texts into embeddings with advanced options

        Args:
            texts: Single text or list of texts
            batch_size: Batch size for processing
            normalize: Normalize embeddings to unit length
            show_progress: Show progress bar
            convert_to_numpy: Return numpy array instead of torch tensor
            pooling: Override default pooling strategy

        Returns:
            Embeddings as numpy array or torch tensor
        """
        # Ensure texts is a list
        if isinstance(texts, str):
            texts = [texts]

        # Validate inputs
        if not texts:
            raise ValueError("Empty text list provided")

        # Check for excessively long texts
        for i, text in enumerate(texts):
            if len(text) > self.max_seq_length * 10:
                logger.warning(
                    f"Text {i} is very long ({len(text)} chars), "
                    "will be truncated"
                )

        try:
            # Use sentence-transformers encode method
            embeddings = self.model.encode(
                texts,
                batch_size=batch_size,
                show_progress_bar=show_progress,
                convert_to_numpy=convert_to_numpy,
                normalize_embeddings=normalize,
                device=self.device,
            )

            return embeddings

        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                logger.error(
                    f"GPU OOM with batch_size={batch_size}. "
                    "Try reducing batch size."
                )
                # Retry with smaller batch size
                if batch_size > 1:
                    logger.info(f"Retrying with batch_size={batch_size // 2}")
                    torch.cuda.empty_cache()
                    return self.encode(
                        texts,
                        batch_size=batch_size // 2,
                        normalize=normalize,
                        show_progress=show_progress,
                        convert_to_numpy=convert_to_numpy,
                        pooling=pooling,
                    )
            raise

    def encode_single(
            self,
            text: str,
            normalize: bool = True,
    ) -> np.ndarray:
        """
        Encode a single text (optimized path)

        Args:
            text: Input text
            normalize: Normalize embedding

        Returns:
            Embedding vector as numpy array
        """
        embedding = self.encode(
            [text],
            batch_size=1,
            normalize=normalize,
            show_progress=False,
            convert_to_numpy=True,
        )
        return embedding[0]

    def get_metadata(self) -> ModelMetadata:
        """Get model metadata"""
        return self._metadata

    def get_dimension(self) -> int:
        """Get embedding dimension"""
        return self.dimension

    def warmup(self, num_samples: int = 5):
        """
        Warmup the model with sample requests

        Args:
            num_samples: Number of warmup samples
        """
        logger.info(f"Warming up model with {num_samples} samples")
        sample_texts = [
            "This is a sample text for model warmup." * (i + 1)
            for i in range(num_samples)
        ]

        try:
            _ = self.encode(
                sample_texts,
                batch_size=min(num_samples, 8),
                show_progress=False,
            )
            logger.info("Model warmup completed successfully")
        except Exception as e:
            logger.warning(f"Model warmup failed: {e}")

    def __repr__(self) -> str:
        return (
            f"EmbeddingModel(name='{self.model_name}', "
            f"dim={self.dimension}, device='{self.device}', "
            f"fp16={self.use_fp16})"
        )