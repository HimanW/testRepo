from typing import Dict, List, Optional
import logging
from threading import Lock

from app.models.embedding_model import EmbeddingModel
from app.core.errors import ModelNotFoundError

logger = logging.getLogger(__name__)


class ModelManager:
    """
    Manages multiple embedding models with lazy loading

    Features:
    - Lazy model loading
    - Model caching
    - Thread-safe model access
    - Resource management
    """

    def __init__(
            self,
            default_model: str,
            available_models: List[str],
            device: Optional[str] = None,
            use_fp16: bool = False,
            cache_dir: Optional[str] = None,
    ):
        """
        Initialize model manager

        Args:
            default_model: Default model identifier
            available_models: List of allowed model identifiers
            device: Device to load models on
            use_fp16: Use half precision
            cache_dir: Directory to cache models
        """
        self.default_model = default_model
        self.available_models = set(available_models)
        self.device = device
        self.use_fp16 = use_fp16
        self.cache_dir = cache_dir

        # Model cache
        self._models: Dict[str, EmbeddingModel] = {}
        self._lock = Lock()

        logger.info(
            f"Model manager initialized with {len(available_models)} available models"
        )

    def is_model_available(self, model_name: str) -> bool:
        """Check if a model is available"""
        return model_name in self.available_models

    def load_model(self, model_name: str) -> EmbeddingModel:
        """
        Load a model (or return from cache)

        Args:
            model_name: Model identifier

        Returns:
            EmbeddingModel instance

        Raises:
            ModelNotFoundError: If model is not available
        """
        # Check if model is allowed
        if not self.is_model_available(model_name):
            raise ModelNotFoundError(
                f"Model '{model_name}' is not available. "
                f"Available models: {', '.join(self.available_models)}"
            )

        # Check cache first (without lock for performance)
        if model_name in self._models:
            return self._models[model_name]

        # Acquire lock for loading
        with self._lock:
            # Double-check after acquiring lock
            if model_name in self._models:
                return self._models[model_name]

            # Load model
            logger.info(f"Loading model: {model_name}")

            try:
                model = EmbeddingModel(
                    model_name=model_name,
                    device=self.device,
                    use_fp16=self.use_fp16,
                    cache_dir=self.cache_dir,
                )

                # Cache the model
                self._models[model_name] = model

                logger.info(f"Model loaded successfully: {model_name}")
                return model

            except Exception as e:
                logger.error(f"Failed to load model '{model_name}': {e}")
                raise

    def get_model(self, model_name: Optional[str] = None) -> EmbeddingModel:
        """
        Get a model (load if necessary)

        Args:
            model_name: Model identifier (None = use default)

        Returns:
            EmbeddingModel instance
        """
        if model_name is None:
            model_name = self.default_model

        return self.load_model(model_name)

    def unload_model(self, model_name: str) -> bool:
        """
        Unload a model from memory

        Args:
            model_name: Model identifier

        Returns:
            True if model was unloaded
        """
        with self._lock:
            if model_name in self._models:
                del self._models[model_name]
                logger.info(f"Model unloaded: {model_name}")
                return True
            return False

    def list_models(self) -> List[str]:
        """List all available models"""
        return list(self.available_models)

    def list_loaded_models(self) -> List[str]:
        """List currently loaded models"""
        return list(self._models.keys())

    def get_default_model(self) -> str:
        """Get default model identifier"""
        return self.default_model

    def clear_cache(self):
        """Unload all models"""
        with self._lock:
            model_names = list(self._models.keys())
            for model_name in model_names:
                del self._models[model_name]
            logger.info(f"Cleared {len(model_names)} models from cache")

    def get_memory_usage(self) -> Dict[str, float]:
        """
        Get memory usage of loaded models

        Returns:
            Dict mapping model names to memory usage in MB
        """
        usage = {}
        for model_name, model in self._models.items():
            metadata = model.get_metadata()
            usage[model_name] = metadata.memory_usage_mb
        return usage

    def __len__(self) -> int:
        """Number of loaded models"""
        return len(self._models)