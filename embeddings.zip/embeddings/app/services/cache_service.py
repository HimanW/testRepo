from typing import Optional, List, Dict, Any
import hashlib
import json
import logging
from datetime import timedelta
import redis.asyncio as redis
from redis.asyncio import Redis
from redis.exceptions import RedisError
import numpy as np

logger = logging.getLogger(__name__)


class CacheService:
    """
    Enterprise Redis caching service for embeddings

    Features:
    - Content-based cache keys (hashed)
    - Batch get/set operations
    - TTL management
    - Circuit breaker for Redis failures
    - Compression for large embeddings
    """

    def __init__(
            self,
            redis_url: str,
            ttl: int = 3600,
            max_size: int = 10000,
            key_prefix: str = "emb:",
            enabled: bool = True,
    ):
        """
        Initialize cache service

        Args:
            redis_url: Redis connection URL
            ttl: Time to live for cache entries (seconds)
            max_size: Maximum number of entries (LRU eviction)
            key_prefix: Prefix for all cache keys
            enabled: Enable/disable caching
        """
        self.redis_url = redis_url
        self.ttl = ttl
        self.max_size = max_size
        self.key_prefix = key_prefix
        self.enabled = enabled

        self._client: Optional[Redis] = None
        self._connected = False
        self._failure_count = 0
        self._max_failures = 3

        # Statistics
        self._stats = {
            "hits": 0,
            "misses": 0,
            "errors": 0,
            "sets": 0,
        }

    async def connect(self):
        """Establish Redis connection"""
        if not self.enabled:
            logger.info("Cache is disabled")
            return

        try:
            self._client = await redis.from_url(
                self.redis_url,
                encoding="utf-8",
                decode_responses=False,  # We'll handle binary data
                socket_timeout=5.0,
                socket_connect_timeout=5.0,
                retry_on_timeout=True,
                max_connections=50,
            )

            # Test connection
            await self._client.ping()
            self._connected = True
            self._failure_count = 0
            logger.info("Successfully connected to Redis")

        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self._connected = False
            self.enabled = False

    async def disconnect(self):
        """Close Redis connection"""
        if self._client:
            await self._client.close()
            self._connected = False
            logger.info("Disconnected from Redis")

    def _generate_cache_key(
            self,
            text: str,
            model_name: str,
            normalize: bool = True,
    ) -> str:
        """
        Generate deterministic cache key from text and parameters

        Args:
            text: Input text
            model_name: Model identifier
            normalize: Whether normalization is enabled

        Returns:
            Cache key string
        """
        # Create a deterministic hash of the inputs
        content = f"{text}|{model_name}|{normalize}"
        hash_obj = hashlib.sha256(content.encode('utf-8'))
        text_hash = hash_obj.hexdigest()[:16]  # Use first 16 chars

        return f"{self.key_prefix}{text_hash}"

    def _serialize_embedding(self, embedding: np.ndarray) -> bytes:
        """Serialize numpy array to bytes"""
        return embedding.tobytes()

    def _deserialize_embedding(
            self,
            data: bytes,
            dimension: int,
    ) -> np.ndarray:
        """Deserialize bytes to numpy array"""
        return np.frombuffer(data, dtype=np.float32).reshape(-1, dimension)

    async def get(
            self,
            text: str,
            model_name: str,
            dimension: int,
            normalize: bool = True,
    ) -> Optional[np.ndarray]:
        """
        Get embedding from cache

        Args:
            text: Input text
            model_name: Model identifier
            dimension: Expected embedding dimension
            normalize: Normalization flag

        Returns:
            Cached embedding or None if not found
        """
        if not self.enabled or not self._connected:
            return None

        if self._failure_count >= self._max_failures:
            return None

        try:
            key = self._generate_cache_key(text, model_name, normalize)
            data = await self._client.get(key)

            if data:
                self._stats["hits"] += 1
                embedding = self._deserialize_embedding(data, dimension)
                logger.debug(f"Cache hit for key: {key}")
                return embedding
            else:
                self._stats["misses"] += 1
                return None

        except RedisError as e:
            self._stats["errors"] += 1
            self._failure_count += 1
            logger.warning(f"Redis get error: {e}")
            return None

    async def get_many(
            self,
            texts: List[str],
            model_name: str,
            dimension: int,
            normalize: bool = True,
    ) -> Dict[str, Optional[np.ndarray]]:
        """
        Get multiple embeddings from cache (batch operation)

        Args:
            texts: List of input texts
            model_name: Model identifier
            dimension: Expected embedding dimension
            normalize: Normalization flag

        Returns:
            Dict mapping texts to cached embeddings (None if not cached)
        """
        if not self.enabled or not self._connected:
            return {text: None for text in texts}

        try:
            # Generate cache keys
            keys = [
                self._generate_cache_key(text, model_name, normalize)
                for text in texts
            ]

            # Batch get using pipeline
            pipe = self._client.pipeline()
            for key in keys:
                pipe.get(key)

            results = await pipe.execute()

            # Deserialize results
            embeddings = {}
            for text, data in zip(texts, results):
                if data:
                    self._stats["hits"] += 1
                    embeddings[text] = self._deserialize_embedding(data, dimension)
                else:
                    self._stats["misses"] += 1
                    embeddings[text] = None

            return embeddings

        except RedisError as e:
            self._stats["errors"] += 1
            self._failure_count += 1
            logger.warning(f"Redis get_many error: {e}")
            return {text: None for text in texts}

    async def set(
            self,
            text: str,
            embedding: np.ndarray,
            model_name: str,
            normalize: bool = True,
    ) -> bool:
        """
        Store embedding in cache

        Args:
            text: Input text
            embedding: Embedding vector
            model_name: Model identifier
            normalize: Normalization flag

        Returns:
            True if successfully cached
        """
        if not self.enabled or not self._connected:
            return False

        try:
            key = self._generate_cache_key(text, model_name, normalize)
            data = self._serialize_embedding(embedding)

            await self._client.setex(
                key,
                timedelta(seconds=self.ttl),
                data
            )

            self._stats["sets"] += 1
            self._failure_count = max(0, self._failure_count - 1)
            return True

        except RedisError as e:
            self._stats["errors"] += 1
            self._failure_count += 1
            logger.warning(f"Redis set error: {e}")
            return False

    async def set_many(
            self,
            embeddings: Dict[str, np.ndarray],
            model_name: str,
            normalize: bool = True,
    ) -> int:
        """
        Store multiple embeddings (batch operation)

        Args:
            embeddings: Dict mapping texts to embeddings
            model_name: Model identifier
            normalize: Normalization flag

        Returns:
            Number of successfully cached items
        """
        if not self.enabled or not self._connected:
            return 0

        try:
            pipe = self._client.pipeline()

            for text, embedding in embeddings.items():
                key = self._generate_cache_key(text, model_name, normalize)
                data = self._serialize_embedding(embedding)
                pipe.setex(key, timedelta(seconds=self.ttl), data)

            results = await pipe.execute()
            success_count = sum(1 for r in results if r)

            self._stats["sets"] += success_count
            self._failure_count = max(0, self._failure_count - 1)
            return success_count

        except RedisError as e:
            self._stats["errors"] += 1
            self._failure_count += 1
            logger.warning(f"Redis set_many error: {e}")
            return 0

    async def clear(self) -> bool:
        """Clear all cache entries with the service prefix"""
        if not self.enabled or not self._connected:
            return False

        try:
            # Scan and delete keys with our prefix
            cursor = 0
            deleted = 0

            while True:
                cursor, keys = await self._client.scan(
                    cursor,
                    match=f"{self.key_prefix}*",
                    count=100
                )

                if keys:
                    deleted += await self._client.delete(*keys)

                if cursor == 0:
                    break

            logger.info(f"Cleared {deleted} cache entries")
            return True

        except RedisError as e:
            logger.error(f"Failed to clear cache: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self._stats["hits"] + self._stats["misses"]
        hit_rate = (
            self._stats["hits"] / total_requests * 100
            if total_requests > 0
            else 0
        )

        return {
            **self._stats,
            "hit_rate_percent": round(hit_rate, 2),
            "total_requests": total_requests,
            "connected": self._connected,
            "enabled": self.enabled,
        }

    async def health_check(self) -> bool:
        """Check if cache is healthy"""
        if not self.enabled:
            return True  # Always healthy if disabled

        try:
            if not self._connected:
                return False

            await self._client.ping()
            return True
        except:
            return False