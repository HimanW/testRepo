from typing import List, Dict, Optional, Any
import logging
import asyncio
import numpy as np
from concurrent.futures import ThreadPoolExecutor

from app.models.model_manager import ModelManager
from app.services.cache_service import CacheService

logger = logging.getLogger(__name__)


class EmbeddingService:
    """
    High-level embedding service with caching and batching

    Features:
    - Intelligent cache integration
    - Deduplication of identical texts
    - Efficient batch processing
    - Async/await support
    """

    def __init__(
            self,
            model_manager: ModelManager,
            cache_service: Optional[CacheService] = None,
            max_batch_size: int = 32,
    ):
        """
        Initialize embedding service

        Args:
            model_manager: Model manager instance
            cache_service: Optional cache service
            max_batch_size: Maximum batch size for model inference
        """
        self.model_manager = model_manager
        self.cache_service = cache_service
        self.max_batch_size = max_batch_size

        # Thread pool for running sync model code
        self._executor = ThreadPoolExecutor(max_workers=4)

    async def embed_texts(
            self,
            texts: List[str],
            model_name: str,
            normalize: bool = True,
            use_cache: bool = True,
    ) -> Dict[str, Any]:
        """
        Generate embeddings for a list of texts

        Args:
            texts: List of input texts
            model_name: Model to use
            normalize: Normalize embeddings
            use_cache: Use caching if available

        Returns:
            Dict with embeddings and cache hit information
        """
        # Get model
        model = self.model_manager.get_model(model_name)
        dimension = model.get_dimension()

        # Deduplicate texts while preserving order
        unique_texts = []
        text_to_indices = {}

        for i, text in enumerate(texts):
            if text not in text_to_indices:
                text_to_indices[text] = []
                unique_texts.append(text)
            text_to_indices[text].append(i)

        logger.debug(
            f"Processing {len(texts)} texts ({len(unique_texts)} unique)"
        )

        # Try to get from cache
        cached_embeddings = {}
        texts_to_compute = []
        cache_hits = [False] * len(texts)

        if use_cache and self.cache_service:
            cached_embeddings = await self.cache_service.get_many(
                unique_texts,
                model_name,
                dimension,
                normalize,
            )

            for text in unique_texts:
                if cached_embeddings.get(text) is None:
                    texts_to_compute.append(text)
                else:
                    # Mark cache hits
                    for idx in text_to_indices[text]:
                        cache_hits[idx] = True

            logger.debug(
                f"Cache hits: {len(unique_texts) - len(texts_to_compute)}/{len(unique_texts)}"
            )
        else:
            texts_to_compute = unique_texts

        # Compute embeddings for cache misses
        computed_embeddings = {}

        if texts_to_compute:
            # Run model inference in thread pool
            embeddings_array = await asyncio.get_event_loop().run_in_executor(
                self._executor,
                lambda: model.encode(
                    texts_to_compute,
                    batch_size=self.max_batch_size,
                    normalize=normalize,
                    show_progress=False,
                    convert_to_numpy=True,
                )
            )

            # Convert to dict
            for text, embedding in zip(texts_to_compute, embeddings_array):
                computed_embeddings[text] = embedding

            # Cache new embeddings
            if use_cache and self.cache_service:
                await self.cache_service.set_many(
                    computed_embeddings,
                    model_name,
                    normalize,
                )

        # Combine cached and computed embeddings
        all_embeddings = {**cached_embeddings, **computed_embeddings}

        # Reconstruct in original order (handling duplicates)
        result_embeddings = []
        for text in texts:
            embedding = all_embeddings[text]
            if embedding is not None:
                result_embeddings.append(embedding.tolist())
            else:
                # This shouldn't happen, but handle gracefully
                logger.error(f"Missing embedding for text: {text[:50]}...")
                result_embeddings.append([0.0] * dimension)

        return {
            "embeddings": result_embeddings,
            "cached": cache_hits,
        }

    async def embed_single(
            self,
            text: str,
            model_name: str,
            normalize: bool = True,
            use_cache: bool = True,
    ) -> np.ndarray:
        """
        Generate embedding for a single text (convenience method)

        Args:
            text: Input text
            model_name: Model to use
            normalize: Normalize embedding
            use_cache: Use caching if available

        Returns:
            Embedding as numpy array
        """
        result = await self.embed_texts(
            texts=[text],
            model_name=model_name,
            normalize=normalize,
            use_cache=use_cache,
        )

        return np.array(result["embeddings"][0])

    def __del__(self):
        """Cleanup thread pool"""
        if hasattr(self, '_executor'):
            self._executor.shutdown(wait=False)