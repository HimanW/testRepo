"""Text preprocessing utilities"""

import re
from typing import List


def clean_text(text: str) -> str:
    """
    Clean text by removing extra whitespace and normalizing

    Args:
        text: Input text

    Returns:
        Cleaned text
    """
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)

    # Strip leading/trailing whitespace
    text = text.strip()

    return text


def truncate_text(text: str, max_length: int) -> str:
    """
    Truncate text to maximum length

    Args:
        text: Input text
        max_length: Maximum length

    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text

    return text[:max_length]


def batch_texts(texts: List[str], batch_size: int) -> List[List[str]]:
    """
    Split texts into batches

    Args:
        texts: List of texts
        batch_size: Size of each batch

    Returns:
        List of batches
    """
    return [
        texts[i:i + batch_size]
        for i in range(0, len(texts), batch_size)
    ]