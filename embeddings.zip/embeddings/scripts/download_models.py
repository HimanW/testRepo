#!/usr/bin/env python3
"""
Script to pre-download embedding models
This speeds up first startup and ensures models are cached
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sentence_transformers import SentenceTransformer
from app.config import settings


def download_models():
    """Download all configured models"""
    print(f"Downloading models to: {settings.MODEL_CACHE_DIR}")
    print(f"Models to download: {settings.AVAILABLE_MODELS}")

    for model_name in settings.AVAILABLE_MODELS:
        print(f"\nDownloading: {model_name}")
        try:
            model = SentenceTransformer(
                model_name,
                cache_folder=settings.MODEL_CACHE_DIR
            )
            print(f"✓ Successfully downloaded: {model_name}")
            print(f"  - Dimension: {model.get_sentence_embedding_dimension()}")
            print(f"  - Max seq length: {model.max_seq_length}")
        except Exception as e:
            print(f"✗ Failed to download {model_name}: {e}")

    print("\n✓ Model download complete!")


if __name__ == "__main__":
    download_models()