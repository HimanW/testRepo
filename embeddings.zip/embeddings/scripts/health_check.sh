#!/bin/bash
# Health check script for embedding service

set -e

HOST="${HOST:-localhost}"
PORT="${PORT:-8000}"
TIMEOUT="${TIMEOUT:-5}"

# Color output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "Checking embedding service health..."
echo "Host: $HOST:$PORT"

# Check health endpoint
if curl -sf --max-time $TIMEOUT "http://${HOST}:${PORT}/health" > /dev/null; then
    echo -e "${GREEN}✓ Health check passed${NC}"

    # Get detailed health info
    HEALTH_DATA=$(curl -s "http://${HOST}:${PORT}/health")
    echo "Health status: $(echo $HEALTH_DATA | jq -r '.status')"
    echo "Service: $(echo $HEALTH_DATA | jq -r '.service')"
    echo "Version: $(echo $HEALTH_DATA | jq -r '.version')"

    exit 0
else
    echo -e "${RED}✗ Health check failed${NC}"
    exit 1
fi