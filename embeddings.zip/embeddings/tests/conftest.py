"""Pytest configuration and fixtures"""

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client():
    """FastAPI test client fixture"""
    from app.main import app
    return TestClient(app)


@pytest.fixture
def sample_texts():
    """Sample texts for testing"""
    return [
        "Hello world",
        "Machine learning is awesome",
        "Python is a great programming language",
    ]


@pytest.fixture
def single_text():
    """Single text for testing"""
    return "This is a test sentence for embedding."