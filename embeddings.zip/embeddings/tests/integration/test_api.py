"""Integration tests for the embedding API"""

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.config import settings


@pytest.fixture
def client():
    """Test client fixture"""
    return TestClient(app)


class TestHealthEndpoints:
    """Test health check endpoints"""

    def test_health_check(self, client):
        """Test health endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "service" in data
        assert data["service"] == settings.SERVICE_NAME

    def test_readiness_check(self, client):
        """Test readiness endpoint"""
        response = client.get("/ready")
        assert response.status_code in [200, 503]


class TestEmbeddingEndpoints:
    """Test embedding generation endpoints"""

    def test_embed_single_text(self, client):
        """Test embedding a single text"""
        payload = {
            "texts": ["Hello world"],
            "normalize": True,
            "use_cache": False,
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 200

        data = response.json()
        assert "embeddings" in data
        assert len(data["embeddings"]) == 1
        assert "model" in data
        assert "dimension" in data
        assert len(data["embeddings"][0]) == data["dimension"]

    def test_embed_multiple_texts(self, client):
        """Test embedding multiple texts"""
        payload = {
            "texts": [
                "Hello world",
                "Machine learning is awesome",
                "Python is a great language"
            ],
            "normalize": True,
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 200

        data = response.json()
        assert len(data["embeddings"]) == 3
        assert all(len(emb) == data["dimension"] for emb in data["embeddings"])

    def test_embed_with_caching(self, client):
        """Test caching behavior"""
        payload = {
            "texts": ["Cached text example"],
            "use_cache": True,
        }

        # First request (cache miss)
        response1 = client.post("/v1/embed", json=payload)
        assert response1.status_code == 200
        data1 = response1.json()

        # Second request (should hit cache if enabled)
        response2 = client.post("/v1/embed", json=payload)
        assert response2.status_code == 200
        data2 = response2.json()

        # Embeddings should be identical
        assert data1["embeddings"] == data2["embeddings"]

    def test_embed_with_different_models(self, client):
        """Test embedding with different models"""
        text = "Test text for different models"

        for model in settings.AVAILABLE_MODELS[:2]:  # Test first 2 models
            payload = {
                "texts": [text],
                "model": model,
            }

            response = client.post("/v1/embed", json=payload)
            assert response.status_code == 200

            data = response.json()
            assert data["model"] == model

    def test_embed_empty_texts(self, client):
        """Test error handling for empty texts"""
        payload = {
            "texts": [],
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 422  # Validation error

    def test_embed_too_many_texts(self, client):
        """Test error handling for too many texts"""
        payload = {
            "texts": ["text"] * (settings.MAX_TEXTS_PER_REQUEST + 1),
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 400

    def test_embed_invalid_model(self, client):
        """Test error handling for invalid model"""
        payload = {
            "texts": ["Hello"],
            "model": "invalid-model-name",
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 404

    def test_embed_normalization(self, client):
        """Test that normalization works correctly"""
        import numpy as np

        payload = {
            "texts": ["Test normalization"],
            "normalize": True,
            "use_cache": False,
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 200

        data = response.json()
        embedding = np.array(data["embeddings"][0])

        # Check that embedding is normalized (L2 norm ~ 1.0)
        norm = np.linalg.norm(embedding)
        assert abs(norm - 1.0) < 0.01


class TestModelEndpoints:
    """Test model management endpoints"""

    def test_list_models(self, client):
        """Test listing available models"""
        response = client.get("/v1/models")
        assert response.status_code == 200

        data = response.json()
        assert "models" in data
        assert "default_model" in data
        assert len(data["models"]) > 0

        # Check model info structure
        model = data["models"][0]
        assert "name" in model
        assert "dimension" in model
        assert "max_seq_length" in model
        assert "device" in model


class TestCacheEndpoints:
    """Test cache management endpoints"""

    def test_cache_stats(self, client):
        """Test getting cache statistics"""
        if not settings.ENABLE_CACHE:
            pytest.skip("Cache is disabled")

        response = client.get("/v1/cache/stats")

        if response.status_code == 404:
            pytest.skip("Cache endpoint not available")

        assert response.status_code == 200

        data = response.json()
        assert "hits" in data
        assert "misses" in data
        assert "hit_rate_percent" in data

    def test_clear_cache(self, client):
        """Test clearing the cache"""
        if not settings.ENABLE_CACHE:
            pytest.skip("Cache is disabled")

        response = client.post("/v1/cache/clear")

        if response.status_code == 404:
            pytest.skip("Cache endpoint not available")

        assert response.status_code == 200


class TestErrorHandling:
    """Test error handling and edge cases"""

    def test_request_id_header(self, client):
        """Test that request ID is returned in headers"""
        response = client.get("/health")
        assert "X-Request-ID" in response.headers

    def test_process_time_header(self, client):
        """Test that process time is returned in headers"""
        response = client.get("/health")
        assert "X-Process-Time" in response.headers

        process_time = float(response.headers["X-Process-Time"])
        assert process_time >= 0


class TestPerformance:
    """Performance-related tests"""

    def test_batch_processing_performance(self, client):
        """Test that batch processing is faster than individual requests"""
        import time

        texts = [f"Test text {i}" for i in range(10)]

        # Batch request
        start = time.time()
        response = client.post(
            "/v1/embed",
            json={"texts": texts, "use_cache": False}
        )
        batch_time = time.time() - start

        assert response.status_code == 200

        # Individual requests would take longer
        # (This is more of a sanity check than a strict test)
        assert batch_time < 5.0  # Should complete in reasonable time

    def test_deduplication(self, client):
        """Test that duplicate texts are deduplicated"""
        payload = {
            "texts": ["Same text"] * 5,
            "use_cache": False,
        }

        response = client.post("/v1/embed", json=payload)
        assert response.status_code == 200

        data = response.json()

        # All embeddings should be identical
        embeddings = data["embeddings"]
        assert all(emb == embeddings[0] for emb in embeddings)